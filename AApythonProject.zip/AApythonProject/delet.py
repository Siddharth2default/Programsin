from selenium import webdriver
from selenium.webdriver.chrome import options
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

obj1 = Service()
chrome_options = Options()
chrome_options.add_experimental_option('detach',True)
content = webdriver.Chrome(service=obj1,options = chrome_options)
content.get("https://rahulshettyacademy.com/AutomationPractice/")
content.find_element(By.XPATH,"(//input[@type='checkbox'])[3]").click()
radios = content.find_elements(By.CSS_SELECTOR,".radioButton")
radios[2].click()
assert radios[2].is_selected()
assert content.find_element(By.ID,"displayed-text").is_displayed()
content.find_element(By.ID,'hide-textbox').click()
assert not content.find_element(By.ID,"displayed-text").is_displayed()
