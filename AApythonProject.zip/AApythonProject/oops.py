#classes and objects
from user import User

obj1 = User("SID","abc123")
obj2 = User("harry","xyz456")
obj1.register()
obj2.login()
print(obj2.username,obj1.pwd)
print(User.name)
obj1.name = 10
print(obj1.name)