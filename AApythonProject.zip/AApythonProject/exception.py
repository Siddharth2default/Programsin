#exception handling
try:
    num1 = int(input("num1:"))
    num2 = int(input("num2:"))
    result = num1/num2
    print(result)
except ZeroDivisionError as e:
    print("error->",e)
except ValueError as a:
    print("enter only numbers for operation! Value error->",a)
finally:
    print("Bye")

#prime
def prime(num):
    if num == 1:
        print("Nil")
    if num == 2:
        print("PRIME")
    elif num > 2:
        for i in range(2, num):
            if num % i == 0:
                print("Not a prime number")
                break
        else:
            print("Prime number")
    else:
        print("not prime number <1")


c = int(input())
prime(c)