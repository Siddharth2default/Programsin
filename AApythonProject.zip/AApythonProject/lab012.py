num1 = int(input("Enter the first no"))
num2 = int(input("Enter 2 no"))
print(num1)
print(num2)
num3 = num1 + num2
print(num3)