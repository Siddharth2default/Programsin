'''import keyword
print("hello"+"world")
print(keyword.kwlist)
#keyword and identifier
#keywords - reserved words
#variable -
age = 45
print(age)
age = "sid"
print(age)
age ='C'
print(age)
_ ="pink"
print(_)
'''
#-------------
#variables and datatypes
#var_name = var_value
age = 24
#data types
#numbers > integers , float, double
roll_ = -7
phone = 9876543210
#float - decimal no
pi = 3.14
#complex data type
#i - iota - sqrt(-1) > j
#py used in AI, ml, dl, MATH
a= 7+9j
gst = 0.18 #variable
PI = 3.14 #CONSTANT
str = 'S'
name = 'hi'
# print() - fn name is always small letters


print(age,str,name)