#inheritance , method overriding, chaining overview
class Student():

    def __init__(self,name,age):
        self.name = name
        self.age = age
        #print("---Constructor auto-call---")
    def register(self):
        print("Registering>>",self.name,self.age)
    def login(self):
        print("Logged in>>",self.name,self.age)
        return self
    def greet(self):
        print("Overriding")

#obj1 = Student("ram ","24")
#obj2 = Student("Janani ","23")
#obj1.register()
#obj2.login()
class User(Student):
    def greet(self):
        print("User details",self.name,self.age)


class Faculty(Student):
    def greet(self):
        print("faculty details",self.name,self.age)

class Master(Faculty): #multi level
    def greet(self):
        print("master details",self.name,self.age)

class Temp(Faculty,User):
    pass
obj3 = User("mama",45)
#method over chaining
obj3.login().greet()
'''obj4 = Faculty("Mahesh",34)
obj4.greet()
obj5 = Master("Jithu",33)
obj5.greet()
obj5.login() #multi level
obj6 = Temp("sid",77)
obj6.greet()  #multiple inheritance accessing two or more inherited classes
'''