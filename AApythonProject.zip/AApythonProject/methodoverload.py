class Customer: #base or parent class
    user=0
    def __init__(self,name,age):
        print("--------")
        self.name = name
        self.age = age

        Customer.user+=1

    def sync(self):
        print("Logging in..."+self.name+self.age)
    def mail(self):
        print("Registering in..."+self.name+self.age)
        return self
    def greet(self):
        print("Home greet")
class Student(Customer):
    def greet(self):
        print("Hi Student!"+self.name+" "+self.age)
class Faculty(Customer): #child class or derived class
    def greet(self):
        print("Hi Faculty!")
class Temp(Faculty):
    def greet(self):
        print("Multi level",self.name,self.age)

class Tuition(Faculty,Student):
    pass
    #def greet(self):
    #    print("Multiple tuition sessions",self.name,self.age)
obj1 = Customer("sidd ","Pwd34")
obj2 = Student("Hrry","98")
obj3 = Temp("Tempv","ko1")
obj4 = Tuition("Master","vaathiraid5556")
obj2.greet()
obj3.greet()
obj4.greet()
obj1.mail()
obj1.greet()
#method chaining
obj1.mail().greet()