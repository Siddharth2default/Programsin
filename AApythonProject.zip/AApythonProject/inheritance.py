class Customer: #base or parent class
    user=0
    def __init__(self,name,age):
        print("--------")
        self.name = name
        self.age = age

        Customer.user+=1

    def sync(self):
        print("Logging in..."+self.name+self.age)
    def mail(self):
        print("Registering in..."+self.name+self.age)
class Student(Customer):
    def greet(self,fame,num,course,fee):
        super().__init__(fame,num)
        self.course=course
        self.fee=fee
        print("Hi Student!"+self.name+" "+self.age)
class Faculty(Customer): #child class or derived class
    def fleet(self):
        print("Hi Faculty!")
class Temp(Faculty):
    def ship(self):
        print("Multi level",self.name,self.age)
class Tuition(Faculty,Student):
    def session(self):
        print("Multiple tuition sessions",self.name,self.age)
obj1 = Customer("sidd ","Pwd34")
obj1.mail()
obj2 = Customer("Amalaa ","kiDs666")
obj2.sync()
#obj3 = Student("Win","Jay23")
#obj3.greet()
obj4 = Faculty("Mahesh","Maths456")
obj4.fleet()
print("Count class variable", Customer.user)
obj4.sync()
obj5 = Temp("MAss-temp","temp45")
obj5.ship()
obj5.mail() #since multi level can access base class 0 and derived class 1 which inherited before i.e temp faculty-> faculty->customer (only students will not be accessible)
#multiple -> can acess 2 or more classes and inherited properties of those classes
obj6 = Tuition("Kumar","rspuram78")
#obj6.greet()
#obj6.fleet()

obj7= Student('jj',45)
obj7.greet('hero','007','hp','75000')
