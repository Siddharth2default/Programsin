#import email
from mail import * #avoid stars for name conflicts better use above method.
#print(email.activation())
print(otp())
print(activation())