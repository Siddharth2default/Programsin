from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
obj1= Service()
chrome_options = Options()
chrome_options.add_experimental_option("detach",True)
driver = webdriver.Chrome(service=obj1,options=chrome_options)
driver.get("http://rahulshettyacademy.com/dropdownsPractise")
print(driver.current_url)
driver.find_element(By.ID,"autosuggest").send_keys('ind')
time.sleep(2)
countries = driver.find_elements(By.CSS_SELECTOR,"li[class='ui-menu-item'] a")
print(len(countries))
for i in countries:
    #print(i.text)
    if i.text=="India":
        i.click()
        break
