class User:
    name = 0  #class variables
    pwd = None
    def __init__(self,username,pwd):
        self.username=username #instance variables
        self.pwd=pwd
        User.name += 1
    def register(self):
        print("Registering...",self.username,self.pwd)
    def login(self):
        print("Logged in...")

'''class Student(User): #student clss inherits User class > parent class
    def greet(self):
        print("Hi student!")
class Faculty(User): #student clss inherits User class > parent class
    def greet(self):
        print("Hi master!")
'''
