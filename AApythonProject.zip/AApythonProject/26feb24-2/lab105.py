#oops
#encapsulation
#abstraction
#poly
#inheritance
#objects and classes

#class - blue print to create something
#object - a real entity created from the class
#oops - evry object they create have some feature








