set1={1,2,3,4,5}
set2={2,3,4}
sub = set2.issubset(set1)
print(sub)
a=set(["test","xor","test"])
print(a)
for i in a:
    print(i)
set1 = set([1,2,3,4,5,6,10,11,23])
