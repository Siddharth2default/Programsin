c = tuple(["Pramod","lucky"])
print(c)
print(c[1])
h1=("Batman","Bruce")
h2 = ("WW","diana")
h3 = h1+h2
print(h3)
print(list(h3))