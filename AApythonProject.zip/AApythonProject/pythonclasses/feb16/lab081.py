#set - a aset of unique items
set1 ={1,2,3,4,5,4,5}
print(set1)
e1 = set() #empty
e11 ={} #empty
a=[45.2,2,33,33,45,21]
set2 = set(a)
print(len(set2),set2) #unordered unique items