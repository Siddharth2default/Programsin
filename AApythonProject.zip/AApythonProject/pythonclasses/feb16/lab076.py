#tuple we doesnt change these kind of values like websiter
api_urls  = ("sdet.live","aq.com","tta.com")
print(api_urls[0])
print(api_urls[2])