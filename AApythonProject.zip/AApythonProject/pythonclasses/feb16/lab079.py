x = 10
a,b = 23,24
q,w,e =(45,56,78)
#nested tuples
hero1 = ("batman","bruce")
hero2 = ("abaa","basha")
tot = (hero1,hero2)
print(tot)
print(tot[0])
print(tot[1])
print(tot[0][0])
#search in tuple
cities = ["paris","london","cbe"]
print("paris" in cities,"moscow" in cities)