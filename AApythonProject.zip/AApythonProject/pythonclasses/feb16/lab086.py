#dict
#key and vakue
name = "parom"
#key ->name
#value -> pramod
#dict is unordered collection of data
#has key-val pair format
my_dict ={}
my_dict2=dict()
print(type(my_dict),type(my_dict2))
phone={"batman":456,"super":878}
print(phone["batman"],len(phone))
phone2= dict(Batman=123,GB=76,CEASER=None)
print(phone2,type(phone2))






