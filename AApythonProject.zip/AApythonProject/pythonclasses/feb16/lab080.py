#string
name = "Pramod"
#name[0] = 'A' #tyoer error
#in list -> append,clear,pop,del,extend,remove,sort,reversed fn are used.
print(name) #string is bunch of character and immutable
#print(dir(tuple))