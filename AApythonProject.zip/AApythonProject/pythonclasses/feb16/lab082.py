t = ("testing","for","testing")
print(set(t))
set1 ={1,2,3}
set2 ={4,5,6,2}
my_set = set1.union(set2)
my_set2 = set1.intersection(set2)
my_set3 = set1.difference(set2)

print(my_set,my_set2,my_set3)