a=()
b=(1,2,3,4,5)
c= tuple(["Pramod","Lucky",123])
print(a,b,c)
del c
print(c) #name error as it is deleted