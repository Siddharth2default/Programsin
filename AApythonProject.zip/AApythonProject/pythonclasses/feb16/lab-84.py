def fun():
    name ="parmo"
    return name
res= fun()
#def fun2():
 #   name ="psssarmo"
  #  name
#res= fun2()
print(res)