def say(name):
    print("hi",name)
def mac():
    pass #maybe in future we use

def fun2():
    print("dada")

a=max(45,33,3)
print(a)