sq=[1,4,9,16,25]
#index->0,1,2,3,4,..
#rev_index = -5,-4,-3,-2,-1
print(sq[-1])
print(sq[-2],sq[-4],sq[-5])
print(type(sq))

my_list =[]
if list:
    print("empty")
else:
    print("not empty")