sq =[1,4,9,16]
#pop will remove index val
print(sq.pop(1))
print(sq)