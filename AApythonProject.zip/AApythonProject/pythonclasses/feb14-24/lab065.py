my_list = [True,"Pramod",12.34,90]
my_list.sort() #not allowed for diff data type - interview question
print(my_list)