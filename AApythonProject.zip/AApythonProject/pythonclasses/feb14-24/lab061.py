def makepizza(*toppings,base="wheat")
    print(toppings,base)
    for i in toppings:
        print(i)
swathi = makepizza("onion","corn")