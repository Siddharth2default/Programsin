my_list = [1,2,3,4]
print(my_list[0])
my_list.append(12)
mylist.remove(4)
print(my_list)