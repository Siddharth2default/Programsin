a = 180
b = 90
print(a+b,a-b,a*b,a/b)
print(a%b) #modulus  - remainder -0
