x = 10
y = 20
result = (x!=y)
print(result)
#bit wise operator
#>> <<