age = 65
#binary - 0,1 ->10 -> binary
number_ten = 0b1010
#oct
c=0o130
#Hex
d=0x12c
#string
name = 'Pramod'
name2 = 'Pramod'
mul_line ="""This is multi line
string so can exten upto n lines
respectieveuly like this"""
#boolean liters
x= True
y = False
#== ->compare operator
v1 = (1==True)
print(v1)