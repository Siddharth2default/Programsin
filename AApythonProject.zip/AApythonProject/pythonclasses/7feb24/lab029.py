#ternary operator
#x = 10
#y = 20
#a = True
#print(not a)
#will learn in detail later
#string concat
str1 = "Hello"
str2 = "World"
str3 = str1+str2
print(str3)
name = 'prmoa'
age = 33
print(name+str(age)) #kind of type casting
g="Welcome"
g+="world"
print(g)
#increment and decrement
x = 5
x-=1
print(x)
