#logical
x = 10
y = 20
print(x>y,x<y)
a= 10
b= 10
print(a>=b)
print(a>b)
print(a<b)
f= False
t = True
print(f and t) #and
print(f or t)