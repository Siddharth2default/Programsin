# literals
# var_name = var_value
# var_name -> identifier
# var_val -> literals
# literals are actual values assigned
name = "pramod"
# it can be numeric /n non- numeric
name = "pramod"
age = 12 #int
pi = 3.14 #float
char = 'C'
print(type(char)) #always string literal no char in py
is_married = True #boolean literal
have_lambo = None
my_list =[]
my_set = {}
print(type(have_lambo)) #none literal
