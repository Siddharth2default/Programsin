#boolean
#data type - True and False
issidmarried = True
ishahmarried = False
var_jay = 34 #good practice
my_list = [1,2,3,4,5,4]
#unordered collection of items
#sets
#unordered collection of unique items
my_set = {1,2,3,4,5,4}
print(my_set,"\n",my_list)
