def sumof(a,b):
    return a+b

res = sumof(4,5)
print(res)

res = sumof(6.23,7.77)
print(res)

res = sumof("sid","amante")
print(res)