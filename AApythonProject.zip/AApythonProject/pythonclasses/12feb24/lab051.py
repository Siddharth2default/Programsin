#match case#switch
numbers = int(input("enter a number\n"))
match numbers:
