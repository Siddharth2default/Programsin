#continue
for num in range(1,10):
    if num %2 ==0:
        print(f"found even {num}")
        continue
    print(f"found odd {num}")