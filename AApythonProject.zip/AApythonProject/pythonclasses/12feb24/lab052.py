#functions
#built in
result = max(2,3)
sum1 = sum(3,4)
#input("enter number")
import math
res = math.factorial(5)
print(result,sum1)