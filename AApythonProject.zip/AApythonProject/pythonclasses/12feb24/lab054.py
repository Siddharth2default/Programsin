def double(num):
    return num*2
#call the fn - use of return
sal = double(100)
print(sal)

sal = double(1000)
print(sal)