for i in range(1,11):
    if i%3==0:
        print(i)
    else:
        print(i*2)
    print("Hello")