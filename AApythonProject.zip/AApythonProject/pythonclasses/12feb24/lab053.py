def greet():
    print("hellow")
greet()
#result = greet()
#print(result)
#for i in range(5):
    #greet()