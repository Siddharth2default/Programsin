#leap year
def leap(num):
    if((year%4==0)and(year%100!=0)or(year%400==0)):
        return True
    else:
        return False
year = int(input("Year:"))

value = leap(year)
print(value)