#for x in range(5)
#range() is keyword , range is not
x=list(range(5))
print(x)
