a = 10
b = 45
x = 10
y = 67
result1 = ((a>b))
result2 = ((x<y))
print(result1 and result2)