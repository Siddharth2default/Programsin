#loops - repeat a block of code multiple times
print("Hello world")
#for - to iterate of sequence
for i in range(0,5): #0,n-1->4
    print(i)
print("----")
for i in range(1,10,2):
    print(i)


#range -> start,stop,step
print("----")
