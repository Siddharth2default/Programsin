import math
radius = float(input("radius:"))
area = math.pi*pow(radius,2)
print(area)