#condition
#age > 18 -> allowed
#age < 18 -> not allowed
age = int(input("Enter ur age"))
if age>18:
    print("Allowed in club")
else:
    print("not allowed")
a=8
if a==5:
    print("hi")
else:
    print("bye")
x=10
y=20
if(x>y):
    print("x is high")
elif(x<y):
    print("y is hig")
else:
    print("both are equal")