#** power
x=2**3
print(x)
# ^ bitwise xor
a= True
b= False
print(a^b)