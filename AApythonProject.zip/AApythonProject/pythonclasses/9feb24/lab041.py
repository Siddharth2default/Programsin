#while
i = 0
while i<5: #condition
    print(i)
    i+=1