#sq root and cuberoot
import math
number = float(input("Number:"))
sq = number**2
sqrt = math.sqrt(number)
print(sqrt)
cube = number**3
cube = math.pow(number,3)
print(cube)
result = math.sin(number)
print(result)



