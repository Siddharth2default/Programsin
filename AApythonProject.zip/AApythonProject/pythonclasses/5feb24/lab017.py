name = 'Pramod'
print(name[0])
print(name[1])
print(name[2])
print(name[-3])
print(name[-4])
print(name[-5])
print(name[90])