f1 = 10
f2 = 21
f3 = f2/f1
#python int -> div anything high no changces of float
#floor divison is used for int o/p f2//f1
print(f3)
