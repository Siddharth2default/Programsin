name = 'batman'
print(len(name))
print(name[5])
#print(name[6]) - out of rrange
print(len(name)-1)
print(name[len(name)-1])
string = "hello"
#string[0]= 'P' #type error - immutable ->s tring
string = 'ji'
print(string) #can change like this whole