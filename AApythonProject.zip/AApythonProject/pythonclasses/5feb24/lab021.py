#escape seq
#\n - > new line
print("a\nb")
#\a - bell
#\t - tab
#\n - next line
#\f - formfeed ...