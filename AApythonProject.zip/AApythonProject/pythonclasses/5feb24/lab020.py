#int, float , string
#sequence - list
#[]
#list - collection of items
# it can be of different data types
mine =['buttermilk','oranges','apple','flowers']
print(len(mine))
print(mine[-1])
list =[1,2,3,4,True,None,'sid',3.14]
print(type(list),len(list))
del list
print(list)