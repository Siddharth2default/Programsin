val = None #not takes memory
#nothing
#none is not default value
#none is not 0
#none is not same as False
print(val)
print(type(val))
val2 = "" #takes memory
