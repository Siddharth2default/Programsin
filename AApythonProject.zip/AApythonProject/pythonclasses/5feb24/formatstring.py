num = 2
print(f"{num}x1={num}")
print(f"{num}x2={num*2}")
print(f"{num}x3={num*3}")
print(f"{num}x4={num*4}")
print(f"{num}x5={num*5}")
num2 = 5
print("2x{}={}".format(*args,2*num2))
print("{}".format(*args,2))