#strings
#-> bunch of characters
#"" or ''
name = 'SIDD'
name2 = "SIDD"
dir = 'C:\\abc\\abc.txt'
#to get raw string as it is
#dir = r'C:\abc\abc.txt'
print(dir)
print(name2,name)
print(type(name))
age = 24
married = False
print(f"Your name is {name} and age is {age}. i am married -> {married}") # f - format printing as sentence