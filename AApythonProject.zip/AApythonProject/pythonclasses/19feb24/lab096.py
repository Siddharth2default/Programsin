#automation tester blueprint with py System
#class - Students,Courses, Payments-RAzopay,stipe,instamojo
#object -
#student - > vivek,sriram,vani
#course -> pyAtb, MTB, ATBJ, APIAT
class PyATB:
    pass
class Student:
    name = None
    phone=None
    def watch(self):
        print("watch revco")
    def observe(self):
        print("listen reci")
sriram = Student()
sriram.watch()
vani = Student()
vikas = Student()
