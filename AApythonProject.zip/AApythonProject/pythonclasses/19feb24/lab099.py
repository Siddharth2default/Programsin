class Mul_param:
    name = None #class var

    def rin(self,first,last,age):
        a=10 #local
        print("Your name is",first,last,age)
        print(self.name)
obj_ref = Mul_param()
obj_ref.rin("SIDD","amante",68)