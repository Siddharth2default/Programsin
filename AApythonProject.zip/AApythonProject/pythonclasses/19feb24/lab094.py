def base():
    print("layer 1")
def sauces():
    print("layer  2")
def toppings():
    print("layer 3")
    