class Car():
    color = None
    model = None
    def car_details(self):
        print("car details is",self.color,self.model)

car_color = input("Enter color rd:")
car_model = input("Enter model rd:")
obj1 = Car()
obj1.color=car_color
obj1.model=car_model
obj1.car_details()