#try:
#   #try this code, if error
#except:
#   #execute me if try has some error

try:
    c=100/0
except Exception as e:
    print("Error->",e)