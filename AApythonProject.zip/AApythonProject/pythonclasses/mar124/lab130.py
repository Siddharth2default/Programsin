#handle exception
#try and except block
#try -> try the code#except - execute except code(if problem in try
a=int(input("Enter num1"))
b=int(input("Enter num2"))
try:
    c=a/b #Zerodivision error if b=0
    print("Div:",c)
except Exception as e:
    print(e)
    print("0 division, plese dont use b as 0!")

print("Important message that wwe need to show")