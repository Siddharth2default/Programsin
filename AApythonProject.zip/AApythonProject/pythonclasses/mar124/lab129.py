a=int(input("Enter num1"))
b=int(input("Enter num2"))
c=a/b
print("Div:",c)
print("Important message to show")
#exception distrupts normal floww of program

