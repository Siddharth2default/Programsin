from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

obj1 = Service()
chrome_options = Options()
chrome_options.add_experimental_option('detach',True)

driver = webdriver.Chrome(service=obj1,options=chrome_options)
driver.get('https://www.rahulshettyacademy.com/angularpractice')
driver.find_element(By.NAME,"name").send_keys("Clint EastWood")
driver.find_element(By.XPATH,"//input[@id='exampleInputPassword1']").send_keys('1234@sid')
driver.find_element(By.CLASS_NAME,"form-check-input").click()
driver.find_element(By.CSS_SELECTOR,"input[type='submit']").click()
message = driver.find_element(By.CLASS_NAME,"alert-success").text
print(message)
assert "Success" in message
dropdown = Select(driver.find_element(By.ID,"exampleFormControlSelect1"))
dropdown.select_by_index(1)
dropdown.select_by_visible_text('Male')
