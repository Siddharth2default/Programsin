import time

from selenium import webdriver
from selenium.webdriver import chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

#from selenium.webdriver.support.select import Select

obj1 = Service()
chrome_options = Options()
chrome_options.add_experimental_option("detach",True)
driver = webdriver.Chrome(service=obj1,options=chrome_options)
#static dropdown ->
#driver.get("https://rahulshettyacademy.com/angularpractice/")
#driver.maximize_window()
#driver.find_element(By.NAME,"name").send_keys("Winner")
#driver.find_element(By.CSS_SELECTOR,"input[id='exampleInputPassword1']").send_keys("sivaji456")
#obj2 = Select(driver.find_element(By.ID,"exampleFormControlSelect1"))
#obj2.select_by_index(1)
#obj2.select_by_visible_text('Male')
#dynamic dropdown->

driver.get("https://rahulshettyacademy.com/dropdownsPractise/")
driver.find_element(By.ID,"autosuggest").send_keys("Ind")
time.sleep(2)
countries = driver.find_elements(By.XPATH,"//li[@class='ui-menu-item']/a")
for i in countries:
    #print(i)

    if i.text=="India":
        i.click()
        break
print(len(countries))
assert driver.find_element(By.ID,"autosuggest").get_attribute("value")=='India'
#when changing dynamically through script get_attribute is used.



