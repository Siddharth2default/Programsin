import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
obj = Service()
chrome_options = Options()
chrome_options.add_experimental_option('detach',True)
driver = webdriver.Chrome(service=obj,options=chrome_options)
driver.get('https://rahulshettyacademy.com/seleniumPractise/')
driver.find_element(By.CSS_SELECTOR,".search-keyword").send_keys('ber')
time.sleep(2)
products = driver.find_elements(By.XPATH,"//div[@class='products']/div")
count = len(products) #to know the count of list of values.
print(count)
for cart in products:
    cart.find_element(By.XPATH,"div/button").click() #chaining of web elements shrinking search from driver to products i.e to sepeicifc segment search







