def activation():
    link =" zzzzz"
    msg = "Your message is"+link
    return msg
def otp():
    otp = 5678
    msg = "your otp dont share to anyone is :"+str(otp)
    return msg
