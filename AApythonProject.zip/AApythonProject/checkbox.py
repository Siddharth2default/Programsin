from selenium import webdriver
from selenium.webdriver import chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
obj1 = Service()
chrome_options = Options()
chrome_options.add_experimental_option("detach",True)
driver = webdriver.Chrome(service=obj1,options=chrome_options)
driver.get('https://rahulshettyacademy.com/AutomationPractice/')
box = driver.find_elements(By.XPATH,"//input[@type='checkbox']")
#radio = driver.find_elements(By.CSS_SELECTOR,"input[type='radio']")
#above list of values
print(len(box))
#box[2].click()
#print(len(radio))
'''
for j in box :
    if j.get_attribute("value")=='option2':
        j.click()
        assert j.is_selected()

        break
print("Next radio button>")

for i in radio:
    if i.get_attribute("value")=="radio2":
        i.click()
        assert i.is_selected()
'''
buttons = driver.find_elements(By.CSS_SELECTOR,".radioButton")
print(len(buttons))
buttons[0].click()
assert buttons[0].is_selected()

#display
assert driver.find_element(By.ID,"displayed-text").is_displayed()
driver.find_element(By.ID,"hide-textbox").click()
assert not driver.find_element(By.ID,"displayed-text").is_displayed()