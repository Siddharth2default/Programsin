#factorial - 5*4*3*2*1
rows = int(input())
for i in range(rows):
    # Print spaces
    for j in range(rows - i - 1):
        print(" ", end="")

    # Print increasing alphabets
    # Move to next line
    for j in range(i + 1):
        print(chr(65 + j), end=" ")

    print()
# Lower half (reversed upper half)
