'''
___*
__* *
_* * *
* * * *
----------
_* * *
__* *
___*
'''
rows = 5

for i in range(rows):
    # Print spaces
    for _ in range(rows - i - 1):
        print(" ", end=" ")
    # Print increasing alphabets
    for j in range(i + 1):
        print(chr(65 + j), end=" ")
    print()  # Move to next line

for i in range(rows - 2, -1, -1):
    # Print spaces
    for _ in range(rows - i - 1):
        print(" ", end=" ")
    # Print decreasing alphabets (excluding middle character)
    for j in range(i, -1, -1):
        print(chr(65 + j), end=" ")
    print()



