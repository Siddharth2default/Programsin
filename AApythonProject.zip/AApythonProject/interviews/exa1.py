#diamond pattern
#       *
'''
   *
  * *
 * * *
* * * *
'''
row = int(input("rows:"))
for i in range(row):
    print(" "*(row-i)+chr(65+i)*(i+1))

for j in range(row-1):
    print(" "*(j+2)+" *"*(row-j-1))


