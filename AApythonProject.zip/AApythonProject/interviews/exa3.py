num = int(input("value:"))
f1=0
f2=1
f3=0
for i in range(0,num+1):

    f1=f2
    f2=f3
    print(f3)
    f3=f1+f2


