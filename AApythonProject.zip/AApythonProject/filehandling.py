with open("\\home\\ANT.AMAZON.COM\\ssiddhab\\Desktop\\apkfile.txt") as file:
    print(file.read())
print(file.closed)
#using with it is auto-closed after read the file.
